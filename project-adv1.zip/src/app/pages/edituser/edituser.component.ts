import { Component } from '@angular/core';

@Component({
  selector: 'app-edituser',
  standalone: true,
  imports: [],
  templateUrl: './edituser.component.html',
  styleUrl: './edituser.component.scss'
})
export class EdituserComponent {

}
